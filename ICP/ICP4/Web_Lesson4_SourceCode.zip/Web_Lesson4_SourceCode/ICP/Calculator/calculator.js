angular.module('CalculatorApp', [])
    .controller('CalculatorController', function ($scope) {
        // Write code simple calculator operations
    });